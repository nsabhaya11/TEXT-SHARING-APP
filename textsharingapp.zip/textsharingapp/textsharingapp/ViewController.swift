//
//  ViewController.swift
//  textsharingapp
//
//  Created by MACOS on 11/23/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnclick(_ sender: AnyObject) {
        
        
        shareapp(text: "hello", img: nil, url: nil)
        
    }

    func shareapp(text:String? = nil,img:UIImage? = nil,url:URL? = nil)  {
        
        var arr  = Array<Any>();
        
        if text != "" {
            
            arr.append(text);
            
        }
        
        if img != nil {
            
            arr.append(img);
            
        }
        
        if url != nil {
        
            arr.append(url);
            
            
        }
        
        
        let activity = UIActivityViewController(activityItems: arr, applicationActivities: nil);
        
        self.present(activity, animated: true, completion: nil);
        
        
    }
    
}

